//run jquery
$(document).ready(function(){
//fcc stream info and status api call
  var url= "https://wind-bow.gomix.me/twitch-api/channels/freeCodeCamp";
  var url= "https://wind-bow.gomix.me/twitch-api/channels/rocketleague";
  var url= "https://wind-bow.gomix.me/twitch-api/channels/mlg";
  $.ajax({
type: 'GET',
url: 'https://api.twitch.tv/kraken/channels/rocketleague',
headers: {
   'Client-ID': 'xvngr9pwfcipnju8mnfgcerkgxl0a9'
},
success: function(data) {
   console.log(data);
  if (data){
    document.getElementById('rlStatus').innerHTML  = data.status;
    
  }
 
}
});
    $.ajax({
type: 'GET',
url: 'https://api.twitch.tv/kraken/channels/mlg',
headers: {
   'Client-ID': 'xvngr9pwfcipnju8mnfgcerkgxl0a9'
},
success: function(data) {
   console.log(data);
  if (data){
    document.getElementById('mlgStatus').innerHTML  = data.status;
    
  }
 
}
});
  $.ajax({
type: 'GET',
url: 'https://api.twitch.tv/kraken/channels/freecodecamp',
headers: {
   'Client-ID': 'xvngr9pwfcipnju8mnfgcerkgxl0a9'
},
success: function(data) {
   console.log(data);
  if (data){
    document.getElementById('fccStatus').innerHTML  = data.status;
    
  }
 
}
});
});




//run jquery
